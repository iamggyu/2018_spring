#include "complex.h"

Complex::Complex() {
	re = 0;
	im = 0;
}
Complex::Complex(int r, int i) {
	re = r;
	im = i;
}
Complex Complex::operator+(const Complex& c) {
	return Complex(re + c.re, im + c.im);
}
Complex Complex::operator-(const Complex& c) {
	return Complex(re - c.re, im - c.im);
}
Complex Complex::operator*(const Complex& c) {
	return Complex(re * c.re - im * c.im, re * c.im + im * c.re);
}
ostream& operator<<(ostream& os, Complex& c) {
	os << "(" << c.re << " + " << c.im << "i)" << endl;
	return os;
}