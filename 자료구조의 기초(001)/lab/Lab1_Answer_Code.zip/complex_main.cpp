#include "complex.h"

int main() {

	Complex a;
	Complex b(5, 3);
	Complex c(2, 1);

	cout << a << b << c;
	cout << a + b + c << a - b + c << b - a + c;
	cout << a * b << b * c;

	return 0;
}
