#include "complex.h"

Complex::Complex() {
	// TODO
}
Complex::Complex(int r, int i) {
	// TODO
}
Complex Complex::operator+(const Complex& c) {
	// TODO
}
Complex Complex::operator-(const Complex& c) {
	// TODO
}
Complex Complex::operator*(const Complex& c) {
	// TODO
}
ostream& operator<<(ostream& os, Complex& c) {
	// TODO
}