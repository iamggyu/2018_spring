#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>
using namespace std;

class Complex {
private:
	int re, im;
public:
	Complex();
	Complex(int, int);
	Complex operator+(const Complex&);
	Complex operator-(const Complex&);
	Complex operator*(const Complex&);
	friend ostream& operator<<(ostream&, Complex&);
};

#endif
