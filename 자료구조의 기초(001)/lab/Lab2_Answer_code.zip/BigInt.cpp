#include <iostream>
#include <string>

using namespace std;

int* String_To_Int(string Number) {

	int size = Number.size();
	int *NumInt = new int[size];

	for (int i = 0; i < size; i++)
		NumInt[i] = Number[i] - '0';

	return NumInt;
}

void CalculateSum(int *A, int A_size, int *B, int B_size) {

	const int max = (A_size > B_size) ? A_size : B_size;

	int *C = new int[max + 1];
	int i, C_size;
	int a1, b1, carry, sum;

	carry = 0;
	for (i = 0; i <= max; i++) {
		a1 = (i < A_size) ? A[A_size - i - 1] : 0;
		b1 = (i < B_size) ? B[B_size - i - 1] : 0;
		sum = a1 + b1 + carry;
		
		carry = sum / 10;
		C[i] = sum % 10;
	}

	C_size = (C[max] != 0) ? (max + 1) : max;

	cout << "A + B : ";
	for (i = C_size - 1; i >= 0; i--)
		cout << C[i];
	cout << endl;

	delete[] C;
}

int main() {

	string As, Bs;
	int A_size, B_size;
	int *A, *B;

	cout << "Input number A : ";
	cin >> As;
	cout << "Input number B : ";
	cin >> Bs;

	A_size = As.size();
	B_size = Bs.size();

	A = String_To_Int(As);
	B = String_To_Int(Bs);

	CalculateSum(A, A_size, B, B_size);

	delete[] A;
	delete[] B;
}