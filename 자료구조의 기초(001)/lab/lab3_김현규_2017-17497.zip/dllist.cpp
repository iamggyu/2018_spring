#include "sllist.h"

list::node::node(int n) {
	num = n;
	next = nullptr;
}
list::node::node(int n, node* link) {
	num = n;
	next = link;
}
void list::node::setNext(node* link) {
	next = link;
}
list::node* list::node::getNext() {
	return next;
}
int list::node::getNum() {
	return num;
}
list::list() {
	head = new node(0, nullptr);
	size = 0;
}
list::~list() {
	node* curr = head;
	while (curr != nullptr)
	{
		node* temp = curr->getNext();
		delete curr;
		curr = temp;
	}
}
list::node* list::find(int num) {
	node* temp = head;
	while (temp->getNext() != nullptr) {
		temp = temp->getNext();
		if (temp->getNum() == num) break;
	}
	if (temp->getNum() == num)
		return temp;
	else
		return nullptr;
}
void list::insert(int k, int num) {
	node* temp = head;
	if (size < k || k < 0) return;
	while (k > 0 && temp->getNext() != nullptr) {
		temp = temp->getNext();
		k--;
	}
	node *newNode = new node(num, temp->getNext());
	temp->setNext(newNode);
	size++;
}
void list::remove(int k) {
	node* curr = head;
	if (size < k || k < 0) return;
	while (k > 0 && curr->getNext() != nullptr) {
		curr = curr->getNext();
		k--;
	}
	node* temp = curr->getNext();
	curr->setNext(temp->getNext());
	delete temp;
}
int list::getSize() const {
	return size;
}
void list::printAll() {
	node* temp = head;
	while (temp->getNext() != nullptr) {
		temp = temp->getNext();
		cout << temp->getNum() << " ";
	}
	cout << endl;
}