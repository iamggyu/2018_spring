#include<iostream>
using namespace std;

#pragma once

class list {
private:
class node {
private:
int num;
node* next;
public:
node(int);
node(int, node*);
void setNext(node*);
node* getNext();
int getNum();
};
node* head;
int size;
public:
list();
~list();
node* find(int);
void insert(int, int);
void remove(int);
int getSize() const;
void printAll();
};