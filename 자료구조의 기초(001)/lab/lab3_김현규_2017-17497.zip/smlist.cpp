#include "smlist.h"

list::node::node(int _idx, int _data) {
	idx = _idx;
	data = _data;
	next = nullptr;
}
list::node::node(int _idx, int _data, node* link) {
	idx = _idx;
	data = _data;
	next = link;
}
void list::node::setNext(node* link) {
	next = link;
}
list::node* list::node::getNext() {
	return next;
}
int list::node::getIdx() {
	return idx;
}
int list::node::getData() {
	return data;
}
list::list() {
	head = new node(0, 0, nullptr);
	size = 0;
}
list::~list() {
	node* curr = head;
	while (curr != nullptr)
	{
		node* temp = curr->getNext();
		delete curr;
		curr = temp;
	}
}
list::node* list::find(int idx) {
	node* temp = head;
	while (temp->getNext() != nullptr) {
		temp = temp->getNext();
		if (temp->getIdx() == idx) break;
	}
	if (temp->getIdx() == idx)
		return temp;
	else
		return nullptr;
}
void list::insert(int idx, int data) {
	node* temp = head;
	while (temp->getNext() != nullptr) {
		temp = temp->getNext();
	}
	node *newNode = new node(idx, data, temp->getNext());
	temp->setNext(newNode);
	size++;
}
void list::remove(int k) {
	node* curr = head;
	if (size < k || k < 0) return;
	while (k > 0 && curr->getNext() != nullptr) {
		curr = curr->getNext();
		k--;
	}
	node* temp = curr->getNext();
	curr->setNext(temp->getNext());
	delete temp;
}
int list::getSize() const {
	return size;
}
void list::printAll() {
	node* temp = head;
	while (temp->getNext() != nullptr) {
		temp = temp->getNext();
		cout << '(' << temp->getIdx() << ", " << temp->getData()<<")";
	}
	cout << endl;
}
