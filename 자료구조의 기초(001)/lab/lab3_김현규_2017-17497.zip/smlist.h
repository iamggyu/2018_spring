#include<iostream>
using namespace std;

#pragma once

class list {
private:
	class node {
	private:
		int idx, data;
		node* next;
	public:
		node(int, int);
		node(int, int, node*);
		void setNext(node*);
		node* getNext();
		int getIdx();
		int getData();
	};
	node* head;
	int size;
public:
	list();
	~list();
	node* find(int);
	void insert(int, int);
	void remove(int);
	int getSize() const;
	void printAll();
};