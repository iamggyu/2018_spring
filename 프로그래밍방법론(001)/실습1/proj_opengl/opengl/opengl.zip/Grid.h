#pragma once
class Grid {
public:
	Grid(int xx, int yy);
	int x;
	int y;
	void draw();
};