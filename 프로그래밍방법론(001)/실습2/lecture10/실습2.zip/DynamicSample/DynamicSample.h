#pragma once  

#ifdef MATHLIBRARY_EXPORTS  
#define MATHLIBRARY_API __declspec(dllexport)   
#else  
#define MATHLIBRARY_API __declspec(dllimport)   
#endif  


MATHLIBRARY_API double Min(const double *Numbers, const int Count);
MATHLIBRARY_API double Max(const double *Numbers, const int Count);
MATHLIBRARY_API double Sum(const double *Numbers, const int Count);
MATHLIBRARY_API double Average(const double *Numbers, const int Count);
MATHLIBRARY_API long GreatestCommonDivisor(long Nbr1, long Nbr2);

